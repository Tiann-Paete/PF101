﻿using System;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class computeResultButton : Form
    {
        public computeResultButton()
        {
            InitializeComponent();
            // Set the event handler for the button click event
            button1.Click += button1_Click;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(firstNumberTextBox.Text) || string.IsNullOrWhiteSpace(secondNumberTextBox.Text))
            {
                MessageBox.Show("Please enter valid numbers in both fields.");
                return;
            }

            if (!double.TryParse(firstNumberTextBox.Text, out double firstNumber) || !double.TryParse(secondNumberTextBox.Text, out double secondNumber))
            {
                MessageBox.Show("Please enter valid numbers in both fields.");
                return;
            }

            string selectedOperation = operationComboBox.SelectedItem as string;
            if (selectedOperation == null)
            {
                MessageBox.Show("Please select an operation.");
                return;
            }

            double result = 0;
            switch (selectedOperation)
            {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber == 0)
                    {
                        MessageBox.Show("Cannot divide by zero.");
                        return;
                    }
                    result = firstNumber / secondNumber;
                    break;
                default:
                    MessageBox.Show("Invalid operation selected.");
                    return;
            }

            // Display the result in the resultTextBox
            resultTextBox.Text = result.ToString();
        }
    }
}
